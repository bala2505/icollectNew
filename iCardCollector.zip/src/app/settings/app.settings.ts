export const AppSettings = {
    LOGO_URL: '',
    LOGO_URL_TRANS: '',
    LOGOTINY_URL: '',
    COPYRIGHT: '',
    SITE_NAME: 'Lixil',
    IMAGE_FORMAT: ['JPG', 'JPEG', 'PNG'],
    MAX_IMAGE_SIZE: 2,
    OFFICIAL_EMAIL:'',
    ENCRYPTION:true,
    ERROR_PROFILE_IMAGE: ['assets/images/avatar.png'],
    REDIRECT_CODE: {
        'redirectlogin': '/login',
        'lixilDashboard': '/home',        
    },
    EXPERIENCE:[1,2,3,4,5,6,7,8,9,10],
    COMMUNICATIONWEIGHTAGE:[1,2,3,4,5,6,7,8,9,10],
    NOTICEPERIOD:[15,30,45,60],
    CTC:[1,2,3,4,5,6,7,8,9,10],
    PRIORITY:['HIGH','NORMAL','LOW'],
    SHIFTS: [{'ID':0,'Value':'REGULAR'},{'ID':1,'Value':'SHIFT'}],
    DOMESTICTRAVEL :  [{'ID':1,'Value':'YES'},{'ID':0,'Value':'NO'}],
    INTERNATIONALTRAVEL:[{'ID':1,'Value':'YES'},{'ID':0,'Value':'NO'}],
    CLIENTINTERACTION : [{'ID':1,'Value':'YES'},{'ID':0,'Value':'NO'}],
    PASSWORD_REGEX: '[a-zA-Z0-9@/_/.]+',
    CANDIDATE_STATUS: [
        { StatusID: 1, Status: 'Scheduled' },
        { StatusID: 2, Status: 'On Hold' },
        { StatusID: 3, Status: 'Rejected' },
        { StatusID: 4, Status: 'Selected' },
    ],
    IDLE_SESSION: {
        TIMEOUT: 540,
        WARNING_TIMEOUT: 60
    },
    LOGOUT_TYPES: [
        { type: 'regular', url: '' },
        { type: 'inactivity', url: 'error/inactivity' },
        { type: 'pageRefresh', url: 'error/pageRefresh' },
        { type: 'pageBack', url: 'error/pageBack' },
    ],
    BROWSER_VERSIONS: {
        CHROME: 60,
        FIREFOX: 55,
        EDGE: 13,
        IE: 10,
        SAFARI: 10
    }
};
