export const ApiSettings = {    
    //http://icollectcardsapp.com
    // COLLECTIONPAGEURL : 'http://project.rayaztech.com/icollect_new/collections/',
    // USERPAGEURL: 'http://project.rayaztech.com/icollect_new/users/',
    // STATICPAGEBASEURL : 'http://project.rayaztech.com/icollect_new/staticpages/',
   
    API: {
        COLLECTIONPAGEURL : 'http://project.rayaztech.com/icollect_new/collections/',
        USERPAGEURL: 'http://project.rayaztech.com/icollect_cards/users/',
        STATICPAGEBASEURL : 'http://project.rayaztech.com/icollect_new/staticpages/',
        CONTACTPAGEBASEURL : 'http://project.rayaztech.com/icollect_cards/contacts/',
        DASHBOARDPAGEBASEURL : 'http://project.rayaztech.com/icollect_cards/dashboard/',
        COLLECTIONPAGEBASEURL : 'http://project.rayaztech.com/icollect_cards/collections/',

        userLogin: 'ang_login',
        SignUp:'ang_signup',
        appforgotpwd:'ang_forgotpwd',
        updateProfile:'updateProfile',
        getProfile:'getprofiles',
        updatePrivacysetting:'updatePrivacysetting',
        getPrivacysetting:'getprivacysettings',
        getlinkaccounts : 'getlinkaccounts',
        updatelinkaccounts : 'updatelinkaccounts',
        getAboutusPage : "about_us",
        getFaqPage : "faq",
        getPrivacyPolicyPage : 'privacy_policy',
        contactusForm : 'ang_contact',

        Dashboard :{
            getprofile : 'ang_dashboardposts_profile',
            wallpost : 'ang_dashboardposts',
            postStatus : 'ang_adddashboardposts'
        },

        collections : {
            listcollections : "ang_cards"

        }



    }
    
};
