import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
//import { AuthGuard } from './modules/login/auth/helpers/auth.guard';
import { LoginComponent } from './modules/login/login.component';
import { ForgotpasswordComponent } from './modules/forgotpassword/forgotpassword.component';
import { RegistrationComponent } from './modules/registration/registration.component';
import { HomeComponent } from './modules/home/home.component';
import { SetupprofileComponent } from './modules/setupprofile/setupprofile.component';
import { PrivacysettingsComponent } from './modules/privacysettings/privacysettings.component';
import { LinkyouraccountsComponent } from './modules/linkyouraccounts/linkyouraccounts.component';
import { AboutusComponent } from './modules/aboutus/aboutus.component';
import { FaqComponent } from './modules/faq/faq.component';
import { PrivacyComponent } from './modules/privacy/privacy.component';
import { ContactusComponent } from './modules/contactus/contactus.component';
import { CollectionComponent } from './modules/collection/collection.component';

const routes: Routes = [
 { path: 'login', component:LoginComponent },
 { path: 'forgotpassword', component:ForgotpasswordComponent },
 { path: 'registration', component:RegistrationComponent },
 { path: 'setupprofile', component:SetupprofileComponent },
 { path: 'privacysettings', component:PrivacysettingsComponent },
 { path: 'linkyouraccounts', component:LinkyouraccountsComponent },
 { path: 'home', component:HomeComponent },
 { path: 'aboutus', component:AboutusComponent },
 { path: 'faq', component:FaqComponent },
 { path: 'privacy_policy', component:PrivacyComponent },
 { path: 'contact_us', component:ContactusComponent },
 { path: 'collections', component:CollectionComponent },
 // { path: 'home', canActivate: [AuthGuard],loadChildren: '../app/modules/home/home.module#HomeModule'},  
 { path: '', redirectTo: 'login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { } 
