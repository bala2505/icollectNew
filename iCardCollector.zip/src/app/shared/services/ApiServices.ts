import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { HttpClient, HttpResponse, HttpParams } from '@angular/common/http';
import { AuthenticationService } from '../../modules/login/auth/services/authentication.service';
import { User } from '../../modules/login/auth/models/user';


@Injectable({
  providedIn: 'root'
})
export class ApiServices {
    private jwt: User;
    constructor(private http: Http, 
                private httpClient: HttpClient,
                private authenticationService: AuthenticationService) {
    }

    get(url): Observable<any> {
        let response: any;       
        const options = this.setHeaderswithAccessToken();
        return this.http.get(url,options)
            .map((res: Response) => response = res.json())          
            .catch(this.errorHandler);
    }

    post(url, data): Observable<any> {
        let response: any;      
        let options = this.setHeaders();
        return this.http.post(url, data, options)
            .map((res) => response = res)
            .catch(this.errorHandler);
    }
    userpost(url, data): Observable<any> {
        let response: any;      
        let options = this.setHeaderswithAccessToken();       
        return this.http.post(url, data, options)
            .map((res) => response = res)
            .catch(this.errorHandler);
    }

    setHeaders() {
         let headers = new Headers();         
          headers.append('Content-Type', 'application/json');
          headers.append('Access-Control-Allow-Origin', '*');
          return new RequestOptions({ headers: headers });
    }
    setHeaderswithAccessToken() {
         const headers = new Headers();         
          headers.append('Content-Type', 'application/json');
          headers.append('Access-Control-Allow-Origin', '*');
           //headers.append('access-token',localStorage.getItem('accessToken')); 
          //headers.append('access-token','wlluuec35gqckuq'); 
          headers.append('access-token','dujpbne4g0ereq7');
          return new RequestOptions({ headers: headers });
    }
    
    errorHandler(error: Response) {
        console.error('Error on HTTP Call', error);
        return Observable.throw(error || 'Server Error');
    }
}
