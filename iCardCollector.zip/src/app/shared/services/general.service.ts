import { Injectable } from '@angular/core';
import { ApiServices } from './Apiservices';
import { ApiSettings } from '../../settings/app.api-settings';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../../modules/login/auth/models/user';

@Injectable({
  providedIn: 'root'
})
export class GeneralService {

  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  constructor(private ApiServices: ApiServices) {
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));       
    this.currentUser = this.currentUserSubject.asObservable();    
   }

   postUserCredentials(credentials): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.userLogin;
    return this.ApiServices.post(URI,credentials)
    .pipe(map(user => {     
      return user;
    }))
  }
  
  postEmail(email): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.appforgotpwd;
    return this.ApiServices.post(URI,email)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);
  }

  postContactUsDetail(detail): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.CONTACTPAGEBASEURL+ApiSettings.API.contactusForm;;
    return this.ApiServices.post(URI,detail)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);
  }


  registration(detail): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.SignUp;;
    return this.ApiServices.post(URI,detail)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);
  }

  // Update profile detail
  
  setupprofile(detail): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.updateProfile;
    return this.ApiServices.userpost(URI,detail)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);  
  }

  setupPrivacy(detail): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.updatePrivacysetting;
    return this.ApiServices.userpost(URI,detail)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);  
  }

  setupOtherAccounts(detail): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.updatelinkaccounts;
    return this.ApiServices.userpost(URI,detail)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);  
  }


  // Get Profile Detail

  getallAccountsDetailCall(detail): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.getlinkaccounts;
    return this.ApiServices.userpost(URI,detail)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);  
  }

  getProfileDetail(detail): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.getProfile;
    return this.ApiServices.userpost(URI,detail)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);  
  }
  getPrivacyDetail(detail): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.getPrivacysetting;
    return this.ApiServices.userpost(URI,detail)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);  
  }

  /* Static pages */

  getAboutusPage(): Observable<any> {
    let response: any;
    let detail: any = '';
    const URI = ApiSettings.API.STATICPAGEBASEURL+ApiSettings.API.getAboutusPage;    
    return  this.ApiServices.get(URI)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);
  }

  getFaqPage(): Observable<any> {
    let response: any;
    let detail: any = '';
    const URI = ApiSettings.API.STATICPAGEBASEURL+ApiSettings.API.getFaqPage;    
    return  this.ApiServices.get(URI)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);
  }

  getPrivacyPolicyPage(): Observable<any> {
    let response: any;
    let detail: any = '';
    const URI = ApiSettings.API.STATICPAGEBASEURL+ApiSettings.API.getPrivacyPolicyPage;    
    return  this.ApiServices.get(URI)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);
  }


  getDashboardProfile(): Observable<any> {
    let response: any;
    let detail: any = '';
    const URI = ApiSettings.API.DASHBOARDPAGEBASEURL+ApiSettings.API.Dashboard.getprofile;    
    return  this.ApiServices.get(URI)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);
  }

  getWallPost(): Observable<any> {
    let response: any;
    let detail: any = '';
    const URI = ApiSettings.API.DASHBOARDPAGEBASEURL+ApiSettings.API.Dashboard.wallpost+"?user_id=24&page_id=1&limit=1";    
    return  this.ApiServices.get(URI)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);
  }

  postStatus(formData): Observable<any> {
    let response: any;
    const URI = ApiSettings.API.USERPAGEURL+ApiSettings.API.Dashboard.postStatus;
    return this.ApiServices.userpost(URI,formData)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);  
  }

  
  getCollection(): Observable<any> {
    let response: any;
    let detail: any = '';
    const URI = ApiSettings.API.COLLECTIONPAGEBASEURL+ApiSettings.API.collections.listcollections+"?user_id=25&collection_tag_id=1&page_id=1&limit=2";    
    return  this.ApiServices.get(URI)
    .map((res) => response = res)
    .catch(this.ApiServices.errorHandler);
  }

}
