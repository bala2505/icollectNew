import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GeneralService } from '../../shared/services/general.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  contactForm: FormGroup;
  errorMessage : string = '';
  successMessage : string = '';
  submitted : boolean = false; 
  successNote : boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private generalService: GeneralService
  ) { }

  ngOnInit() {
    this.contactForm = this.formBuilder.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required,, Validators.email]],
      message: ['', [Validators.required]]
    });
  }

  // convenience getter for easy access to form fields
get f() { return this.contactForm.controls; }

onSubmit() {   
  this.submitted = true;
  if (this.contactForm.invalid) {
      return;
  }
  let formData;
  formData = {
               "name":this.f.name.value, 
               "email": this.f.email.value, 
               "message": this.f.message.value                 
            }
       
  this.generalService.postContactUsDetail(formData)
  .pipe(first())
  .subscribe(
      data => { 
        let ContactFormDetail = data.json();
        if(ContactFormDetail.code == "200") { 
          this.successNote = true;
          this.successMessage = ContactFormDetail.Message;
        }else{ 
           this.errorMessage = 'Something went wrong';
        }        
      },
      error => {});
    }



      

}
