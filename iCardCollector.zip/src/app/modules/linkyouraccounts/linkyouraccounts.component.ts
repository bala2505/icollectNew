import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup} from '@angular/forms';
import { first } from 'rxjs/operators';
import { GeneralService } from '../../shared/services/general.service';

@Component({
  selector: 'app-linkyouraccounts',
  templateUrl: './linkyouraccounts.component.html',
  styleUrls: ['./linkyouraccounts.component.css']
})
export class LinkyouraccountsComponent implements OnInit {

  linkaccountForm: FormGroup;
  submitted = false;
  successNote = false;
  errorNote = false;
  successMessage = '';
  errorMessage = '';
  ebay : string = '';
  instagram : string = '';
  comc : string = '';
  blowoutcards : string = '';
  eboxlive : string = '';
  playstation : string = '';

  

  constructor( private formBuilder: FormBuilder,
               private generalService: GeneralService,) { }

ngOnInit() {
  this.getAllaccountsDetail();
}
createForm(){
  this.linkaccountForm = this.formBuilder.group({
    'ebay': [this.ebay, [], ],
    'instagram': [this.instagram, [], ],
    'comc': [this.comc, [], ],
    'blowoutcards': [this.blowoutcards, [], ],
    'eboxlive': [this.eboxlive, [], ],
    'playstation': [this.playstation, [], ],
  });

}

 // convenience getter for easy access to form fields
 get f() { return this.linkaccountForm.controls; }

 getAllaccountsDetail(){
  let userData;
  return this.generalService.getallAccountsDetailCall(userData)
  .pipe(first())
  .subscribe(
      data => { 
        data = data.json(); 
        let accountData = data.data;
       
        this.linkaccountForm = this.formBuilder.group({
          'ebay': [accountData.ebay, [], ],
          'instagram': [accountData.instagram, [], ],
          'comc': [accountData.comc, [], ],
          'blowoutcards': [accountData.blowoutcards, [], ],
          'eboxlive': [accountData.eboxlive, [], ],
          'playstation': [accountData.playstation, [], ],
        });
        
      },
      error => {});

 }

 onSubmit() {
   this.submitted = true;

   // stop here if form is invalid
   if (this.linkaccountForm.invalid) {
       return;
   }
   let formData;
   formData = { 
     "ebay":this.f.ebay.value,
     "instagram": this.f.instagram.value, 
     "comc":  this.f.instagram.value ,
     "blowoutcards": this.f.blowoutcards.value,
     "eboxlive":  this.f.eboxlive.value, 
     "playstation": this.f.playstation.value

   };
   this.generalService.setupOtherAccounts(formData)
   .pipe(first())
   .subscribe(
       data => {  
        data = data.json();
         if(data.code == "200") {
           this.successNote = true;
           this.successMessage = 'Links Updated successfully';
         }else{
          this.errorNote = true;
          this.errorMessage = 'error';
         }
          
       },
       error => {});
 }


}
