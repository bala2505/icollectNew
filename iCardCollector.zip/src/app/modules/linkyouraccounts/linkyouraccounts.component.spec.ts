import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkyouraccountsComponent } from './linkyouraccounts.component';

describe('LinkyouraccountsComponent', () => {
  let component: LinkyouraccountsComponent;
  let fixture: ComponentFixture<LinkyouraccountsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkyouraccountsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkyouraccountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
