import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../../shared/services/general.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-privacy',
  templateUrl: './privacy.component.html',
  styleUrls: ['./privacy.component.css']
})
export class PrivacyComponent implements OnInit {

  getPageContent : any;
  getPageTitle : any;

  constructor(private generalService: GeneralService) { }

  ngOnInit() {
    this.getPrivacyPolicyPage();
  }

  getPrivacyPolicyPage(){
    this.generalService.getPrivacyPolicyPage()
    .pipe(first())
    .subscribe(
      data => {      
        this.getPageTitle = data.data.page_title;
        this.getPageContent = data.data.page_content;
      }
    );  
   }


}
