import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GeneralService } from '../../shared/services/general.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup;
  submitted = false;
  successNote = false;
  errorNote = false;
  successMessage : string ='';
  errorMessage : string = '';

  constructor(private formBuilder: FormBuilder,
              private generalService: GeneralService) { }

  ngOnInit() {
        this.forgotPasswordForm = this.formBuilder.group({
          email: ['', [Validators.required, Validators.email]]
        });
  }

  // convenience getter for easy access to form fields
  get f() { return this.forgotPasswordForm.controls; }

  onSubmit() {
    this.submitted = true;
    this.successNote = false;
    this.errorNote = false;
    // stop here if form is invalid
    if (this.forgotPasswordForm.invalid) {
        return;
    }
    let formData;
    formData = { 
      "email":this.f.email.value,
    };
    this.generalService.postEmail(formData)
    .pipe(first())
    .subscribe(
        data => {  
          data = data.json();
          if(data.code == "100") {
            this.successNote = true;
            this.successMessage = data.message;
          }else{
            this.errorNote = true;
            this.errorMessage = data.error_message;
          }
            
        },
        error => {});
  }
}

 


