import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../../shared/services/general.service';
import { first } from 'rxjs/operators';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  profileData : any;
  wallPostData : any;
  urls = [];
  loadImages : boolean = false;
  imageSrc:string = '';
  post_type:string = '1';

  form = new FormGroup({
    status: new FormControl('', Validators.required)    
   });

  constructor( private generalService: GeneralService) { }

  ngOnInit() {
     this.getProfile();
     this.getwallPost();
  }

  postTheStatus(){
    let formData:any;

    if((this.form.get('status').value != '' && this.imageSrc != '')){
        this.post_type = '2';
    }
    formData = {
      "to_user_id" : '',
      "from_user_id" : localStorage.getItem("user_id"),
      "post_description":this.form.get('status').value,
      "images" :  this.imageSrc,
      "post_type" : this.post_type
    }

    this.generalService.postStatus(formData)
    .pipe(first())
    .subscribe(
        data => {  
          alert('Successfully Posted');       
        },
        error => {}); 

  }

    onSelectFile(event:any) {
      if (event.target.files && event.target.files[0]) {
        this.loadImages = true;
        this.imageSrc = event;
          var filesAmount = event.target.files.length;
          for (let i = 0; i < filesAmount; i++) {
                  var reader = new FileReader();
  
                  reader.onload = (event:any) => {
                    console.log(event.target.result);
                     this.urls.push(event.target.result); 
                  }  
                  reader.readAsDataURL(event.target.files[i]);
          }
      }
    }

    getProfile(){
      this.generalService.getDashboardProfile()
      .pipe(first())
      .subscribe(
        data => {
          this.profileData = data;
        }
      );  
    }

    getwallPost(){
      this.generalService.getWallPost()
      .pipe(first())
      .subscribe(
        data => {
          this.wallPostData = data.my_wall_post;
        }
      );  
    }
}
