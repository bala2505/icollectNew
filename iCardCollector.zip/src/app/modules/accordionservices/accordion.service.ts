import { Injectable, EventEmitter } from '@angular/core';

// generate dummy data
const obj = {
  title: 'What are your hours?',
  description: 'We are open 24/7.'
}
const accordionEntries: any[] = [];
for (let i = 0; i < 20; i++) {
  accordionEntries.push(obj);
}

@Injectable({
  providedIn: 'root'
})
export class AccordionService {
  onEntryClick = new EventEmitter();
  entries: any[] = accordionEntries;
  constructor() { }

  collapseAllEntries() {
    this.onEntryClick.emit();
  }
}
