import { Component, Input } from '@angular/core';
import { AccordionService } from '../accordionservices/accordion.service';

@Component({
  selector: 'app-accordion-item',
  template: `
    <dt (click)="onBtnClick()">{{entry.title}}</dt>
    <dd class="{{uncollapsed ? 
      'uncollapsed' : 
      'uncollapsed collapsed'}}">{{entry.description}}</dd>
  `,  
  styleUrls: [ './accordion-item.component.scss' ]
}) 
export class AccordionItemComponent  {
  @Input() entry: any;
  uncollapsed = false;
  constructor(private service: AccordionService ) { }

  ngOnInit() {
    this.service.onEntryClick.subscribe(() => {
      this.uncollapsed = false;
    });
  }

  onBtnClick() {
    this.service.collapseAllEntries();
    this.uncollapsed = true;
  }
}
