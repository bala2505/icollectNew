import { Component, Input } from '@angular/core';
import { AccordionService } from '../accordionservices/accordion.service';
import { GeneralService } from '../../shared/services/general.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-accordion',
  template: `
    <dl class="accordion">
      <app-accordion-item *ngFor="let item of entries" 
      [entry]="item"></app-accordion-item>      
    </dl>
  `,  
  styleUrls: [ './accordion.component.scss' ]
})
export class AccordionComponent  {
  entries: any[];  
  accordionEntries: any;  
  constructor(private service: AccordionService,
    private generalService: GeneralService ) { }

  ngOnInit() {

    this.generalService.getCollection()
    .pipe(first())
    .subscribe(
      data => {
        //this.profileData = data;
        alert(data.total_card_count);


        
        for (let i = 0; i < data.total_card_count; i++) {
          let obj = {
            title: data.data.card_title,
            description: data.data.card_description,
          }
          this.accordionEntries.push(obj);
        }

        console.log(this.accordionEntries);

        this.entries = this.accordionEntries;
      }
    ); 

   
  }

  onBtnClick() {
    this.service.collapseAllEntries();
  }
}
