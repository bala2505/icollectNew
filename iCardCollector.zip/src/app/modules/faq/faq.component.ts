import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../../shared/services/general.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FaqComponent implements OnInit {

  getData : any;

  constructor(private generalService: GeneralService) { }

  ngOnInit() {
    this.getFaqPage();
  }

  getFaqPage(){
    this.generalService.getFaqPage()
    .pipe(first())
    .subscribe(
      data => {
        //console.log(data.data.page_content);        
        this.getData = data.data.page_content;
      }
    );  
   }

}
