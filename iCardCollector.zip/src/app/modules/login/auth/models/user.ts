
export class User {
    accessToken?: string;
}