import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { AuthenticationService } from './auth/services/authentication.service';
import { GeneralService } from '../../shared/services/general.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  invalid:boolean = false;
  successNote = false;
  userNotExist = false;
  userNotExistMessage = '';
 
 
  constructor(
      private formBuilder: FormBuilder,
      private route: ActivatedRoute,
      private router: Router,
      private authenticationService: AuthenticationService,
      private generalService: GeneralService
      
  ) { 
      
  }

  ngOnInit() {
      this.loginForm = this.formBuilder.group({
          username: ['', [Validators.required]],
          password: ['', [Validators.required]]
      });

  }



  
// convenience getter for easy access to form fields
get f() { return this.loginForm.controls; }

 
 
  resetForm(){
    this.loginForm.reset();
    //this.error = "";
  }

  onSubmit() {
   
      this.submitted = true;
      if (this.loginForm.invalid) {
          return;
      }
      let formData;
      formData = {
                   "email":this.f.username.value, 
                   "password": this.f.password.value
                }
           
       this.generalService.postUserCredentials(formData)
          .pipe(first())
          .subscribe(            
              data => { 
               let loginDetail = data.json();
                if(loginDetail.code == "200") {  
                  localStorage.setItem('accessToken', loginDetail.access_token);  
                  localStorage.setItem('user_id', loginDetail.user_id);               
                  this.router.navigate(['home']);
                }else{              
                  this.userNotExist = true;
                  this.userNotExistMessage = 'Invalid Credentials';
                }
                
              },
              error => {});
            }
  }
