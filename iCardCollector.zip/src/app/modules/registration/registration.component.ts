import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GeneralService } from '../../shared/services/general.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  RegistrationForm: FormGroup;
  submitted = false;
  successNote = false;
  userNotExist = false;
  userNotExistMessage = ''; 

  constructor(private formBuilder: FormBuilder,
              private generalService: GeneralService) { }

  ngOnInit() {
    this.RegistrationForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
}

// convenience getter for easy access to form fields
get f() { return this.RegistrationForm.controls; }

onSubmit() {
  this.submitted = true;
  //this.RegistrationForm.get('email') one of the way to get the input from html
  // stop here if form is invalid
  if (this.RegistrationForm.invalid) {
      return;
  }
  let formData;
  formData = { 
          "email":this.f.email.value,
          "password":this.f.password.value       
  };
  

  this.generalService.registration(formData)
  .pipe(first())
  .subscribe(
      data => {  
        if(data.code == "200") {
          this.successNote = true;
        }  
        else if(data.error_code == "101") {
          this.userNotExist = true;
          this.userNotExistMessage = data.error_message;
        }         
      },
      error => {});
}

}
