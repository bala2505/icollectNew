import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { first } from 'rxjs/operators';
import { GeneralService } from '../../shared/services/general.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-setupprofile',
  templateUrl: './setupprofile.component.html',
  styleUrls: ['./setupprofile.component.css']
})
export class SetupprofileComponent implements OnInit {

  setupprofileForm: FormGroup;
  submitted = false;
  successNote = false;
  getFormData :any;
  imageSrc:string = '';
  imageURL:string ;

 // @ViewChild(FileUploaderComponent, {static: false} ) fileuploader;

  constructor( private formBuilder: FormBuilder,
              private generalService: GeneralService,              
              private router: Router,) { }

  getImageData($event) {
    this.imageSrc = $event;
    console.log(this.imageSrc)
  }

  ngOnInit() {
    this.getFormData = this.getProfileDetail();
    this.setupprofileForm = this.formBuilder.group({
      'username': ['', [], ],
      'collection': ['', [], ],
    });
  }

// convenience getter for easy access to form fields
get f() { return this.setupprofileForm.controls; }

getProfileDetail(){
  let userData;
 
  return  this.generalService.getProfileDetail(userData)
  .pipe(first())
  .subscribe(
    data => { 
      data = data.json(); 
      //profile_image
      this.setupprofileForm = this.formBuilder.group({
        'username': [data.data.full_name, [], ],
        'collection': [data.data.interests, [], ],
      });
      console.log(data.data.profile_image);
      this.imageURL = data.data.profile_image;
      
    },
    error => {});
 }
 
  resetForm(){
    this.setupprofileForm.reset();
  }

  onSubmit() {
   
      this.submitted = true;
      if (this.setupprofileForm.invalid) {
          return;
      }    
      let userData = { 
        "name":this.f.username.value,
        "interests":this.f.collection.value,
        "profile_image":this.imageSrc     
    };
       this.generalService.setupprofile(userData)
          .pipe(first())
          .subscribe(
              data => {                                        
                this.router.navigate(['privacysettings']);            
              },
              error => {});
            }


}

