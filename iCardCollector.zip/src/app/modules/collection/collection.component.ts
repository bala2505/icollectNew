import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../../shared/services/general.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-collection',
  templateUrl: './collection.component.html',
  styleUrls: ['./collection.component.css']
})
export class CollectionComponent implements OnInit {

  profileData : any;
  

  constructor( private generalService: GeneralService) { }

  ngOnInit() {
    this.getProfile();
  }

  getProfile(){
    this.generalService.getDashboardProfile()
    .pipe(first())
    .subscribe(
      data => {
        this.profileData = data;
      }
    );  
  }

}
