import { Component, OnInit } from '@angular/core';
import { GeneralService } from '../../shared/services/general.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

  getPageContent : any;
  getPageTitle : string =''

  constructor(
    private generalService: GeneralService) { }

  ngOnInit() {
    this.getAboutusPage();
  }

  getAboutusPage(){
    this.generalService.getAboutusPage()
    .pipe(first())
    .subscribe(
      data => {
        this.getPageTitle = data.data.page_title;
        this.getPageContent = data.data.page_content;
      }
    );  
   }

}
