import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { from } from 'rxjs';
import { first } from 'rxjs/operators';
import { GeneralService } from '../../shared/services/general.service';

@Component({
  selector: 'app-privacysettings',
  templateUrl: './privacysettings.component.html',
  styleUrls: ['./privacysettings.component.css'],
  styles: [ `
    toggle-button {
      margin: 0 auto;
    } 
  `]
})
export class PrivacysettingsComponent implements OnInit {

  privacysettingsForm: FormGroup;
  submitted = false;
  successNote = false;
  flag: string = '';
  pushnotification:string = 'Yes';
  toggleChanged: boolean;
  sendnotificationValue : boolean = false;
  getPrivacy:any;

  

  constructor( private formBuilder: FormBuilder,
    private generalService: GeneralService ,            
    private router: Router) { }

  getToggleEvent($event) {   
    console.log($event);
    // if($event == true){
    //   this.pushnotification = 'Yes'; 
    // }else{
    //   this.pushnotification = 'No'; 
    // }
  }

  ngOnInit() {
    this.getPrivacyDetail();
    // if(this.getPrivacy.push_notification != '')
    //   this.sendnotificationValue = this.getPrivacy.push_notification;
  

      // this.privacysettingsForm = this.formBuilder.group({
      //         privacy: ['private', [], ],
      //         notification: [ this.sendnotificationValue, [], ],
      // });   
  }

  getPrivacyDetail(){
    let userData;
  
    return  this.generalService.getPrivacyDetail(userData)
    .pipe(first())
    .subscribe(
    data => { 
      data = data.json(); 
      let privacy;
      let push_notification;
      //this.sendnotificationValue = data.push_notification;
      console.log(data);
      if(data.data.privacy == "true" ){
        privacy = 'private';
      }else{
        privacy = 'public';
      }

      if(data.data.push_notification == 'Yes' ){
        push_notification = true;
      }else{
        push_notification = false;
      }

      console.log(privacy);
      console.log(push_notification);
      
      this.privacysettingsForm = this.formBuilder.group({
        privacy: [privacy, [], ],
        notification: [ push_notification, [], ],
    });  
      
    },
    error => {});
   }

    // convenience getter for easy access to form fields
  get f() { return this.privacysettingsForm.controls; }

 
 
  resetForm(){
    this.privacysettingsForm.reset();
  }


  onSubmit() {
    if (this.privacysettingsForm.invalid) {
      return;
    }
    console.log(this.f.privacy.value);
    console.log( this.sendnotificationValue);
    
    let privacy =false;
    let formData;
    if(this.f.privacy.value == 'private'){
      privacy = true;
    }
  
    this.submitted = true;
    
    
    formData = { 
                  "privacy":privacy, 
                  "push_notification": this.sendnotificationValue
                };
      this.generalService.setupPrivacy(formData)
        .pipe(first())
        .subscribe(
            data => { 
              this.router.navigate(['linkyouraccounts']);             
            },
            error => {});
          }

}
