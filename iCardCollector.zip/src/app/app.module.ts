import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './modules/login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ForgotpasswordComponent } from './modules/forgotpassword/forgotpassword.component';
import { RegistrationComponent } from './modules/registration/registration.component';
import { HomeComponent } from './modules/home/home.component';
import { SetupprofileComponent } from './modules/setupprofile/setupprofile.component';
import { PrivacysettingsComponent } from './modules/privacysettings/privacysettings.component';
import { LinkyouraccountsComponent } from './modules/linkyouraccounts/linkyouraccounts.component';
import { ToggleButtonComponent } from '../app/modules/privacysettings/toggle-button.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { FileUploaderComponent } from './modules/file-uploader/file-uploader.component';
import { AboutusComponent } from './modules/aboutus/aboutus.component';
import { HeaderComponent } from './shared/components/header/header.component';
import { SidenavigationComponent } from './shared/components/sidenavigation/sidenavigation.component';
import { FooterComponent } from './shared/components/footer/footer.component';
import { FaqComponent } from './modules/faq/faq.component';
import { PrivacyComponent } from './modules/privacy/privacy.component';
import { ContactusComponent } from './modules/contactus/contactus.component';
import { CollectionComponent } from './modules/collection/collection.component';
import { AccordionItemComponent } from './modules/accordion/accordion-item.component';
import { AccordionComponent } from './modules/accordion/accordion.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ForgotpasswordComponent,
    RegistrationComponent,
    HomeComponent,
    SetupprofileComponent,
    PrivacysettingsComponent,
    LinkyouraccountsComponent,
    ToggleButtonComponent,
    FileUploaderComponent,
    AboutusComponent,
    HeaderComponent,
    SidenavigationComponent,
    FooterComponent,
    FaqComponent,
    PrivacyComponent,
    ContactusComponent,
    CollectionComponent,
    AccordionItemComponent,
    AccordionComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    AngularFontAwesomeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
